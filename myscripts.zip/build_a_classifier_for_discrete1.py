# ---http://pbpython.com/categorical-encoding.html


import pandas as pd
from sklearn import tree
from sklearn import preprocessing
from sklearn.feature_extraction import DictVectorizer
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedKFold
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier

from sklearn.gaussian_process.kernels import RBF
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.svm import SVC
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

import numpy as np

clf = tree.DecisionTreeClassifier()

# Define the headers since the data does not have any
headers = ['age','hworkclass','fnlwgt','education',
           'education-num','marital-status','occupation',
           'relationship','race','sex','capital-gain',
           'capital-loss','hours-per-week','native-country','class']

# Read in the CSV file and convert "?" to NaN
df = pd.read_csv('data/adult.data',
                  header=None, names=headers, na_values="?" )
print(df.head())
print(df.dtypes)


print(df.iloc[:,-1])

labels = df.iloc[:,-1]

X, y = df.iloc[:,0:-1].values, df.iloc[:,-1].values

print('X is ')
print(X)

print('y is ')
print(y)

le = preprocessing.LabelEncoder()
dfdf = df.apply(le.fit_transform)
#
# # le.fit(df)
# print(dfdf.head())
# print(dfdf.describe())
print('after encoded')
print(dfdf.iloc[:,-1].values)
dfdfdecoded = le.inverse_transform(dfdf.iloc[:,-1].values)
print(dfdfdecoded)


X, y = dfdf.iloc[:,0:-1].values, dfdf.iloc[:,-1].values
X_train, X_test, y_train, y_test = \
    train_test_split(X, y, test_size=0.3, random_state=0)

print('y_test')
print(y_test)

# classifier = tree.DecisionTreeClassifier()
# classifier = RandomForestClassifier()
# classifier = SVC(kernel="linear", C=0.025)
# classifier = SVC(gamma=2, C=1)
# classifier = SVC()
# classifier = MLPClassifier(alpha=1, hidden_layer_sizes = 1000)
# classifier = MLPClassifier(alpha=1)
# classifier = MLPClassifier()
# classifier = GaussianProcessClassifier(1.0 * RBF(1.0))
classifier = AdaBoostClassifier()
# classifier = QuadraticDiscriminantAnalysis()
# classifier = KNeighborsClassifier(6)
# classifier = classifier.fit(X_train, y_train)


kfold = StratifiedKFold(n_splits=10,
                            random_state=1).split(X_train, y_train)
scores = []
for k, (train, test) in enumerate(kfold):
    classifier.fit(X_train[train], y_train[train])
    score = classifier.score(X_train[test], y_train[test])
    scores.append(score)
    print('Fold: %s, Class dist.: %s, Acc: %.3f' % (k + 1,
                                                    np.bincount(y_train[train]), score))

score = classifier.score(X_test, y_test)
print(score)
print('\nCV accuracy: %.3f +/- %.3f' % (np.mean(scores), np.std(scores)))


#
# obj_df = df.select_dtypes(include=['object']).copy()
# X_dict = obj_df.T.to_dict().values()
# vect = DictVectorizer(sparse=False)
# X_vector = vect.fit_transform(X_dict)
#
# print(X_vector.shape)
#
#
# print(X_vector[:,-1])
# print(X_vector[:,-1])
#
# clf = tree.DecisionTreeClassifier()
# clf = clf.fit(X_vector[:,:-1], X_vector[:,-1])
# # clf = clf.fit(df[:-1], df[-1:-1])