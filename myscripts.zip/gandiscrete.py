from __future__ import absolute_import
from __future__ import division
from __future__ import print_function


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

import tensorflow as tf

# import generate_data as gd


def simplyplot():
    plt.style.use('ggplot')
    original = pd.read_csv('test2.csv')
    # original = gd.genran2()




    #----------------------------------------------
    scale = 2.5
    fig, axs = plt.subplots(2, 3, figsize=(9*scale, 3*scale), sharey=True)
    # original.plot.bar(stacked=True)
    # original.plot.hist(stacked=True)
    # ser = pd.Series(original['A'])
    # original['A'].value_counts(sort=False).plot(ax = axs[0,0],kind ='bar')
    # original['B'].value_counts(sort=False).plot(ax = axs[0,1],kind ='bar')
    # original['C'].value_counts(sort=False).plot(ax = axs[0,2],kind ='bar')
    # original['D'].value_counts(sort=False).plot(ax = axs[1,0],kind ='bar')
    # original['E'].value_counts(sort=False).plot(ax = axs[1,1],kind ='bar')
    # original['F'].value_counts(sort=False).plot(ax = axs[1,2],kind ='bar')


    #----------------------------------------------

    original['A'].plot(ax = axs[0,0],kind ='hist')
    original['B'].plot(ax = axs[0,1],kind ='hist')
    original['C'].plot(ax = axs[0,2],kind ='hist')
    original['D'].plot(ax = axs[1,0],kind ='hist')
    original['E'].plot(ax = axs[1,1],kind ='hist')
    original['F'].plot(ax = axs[1,2],kind ='hist')


    plt.show()
    #----------------------------------------------


    original.plot(kind = 'density')


    plt.show()




def main():


    original = pd.read_csv('test2.csv', float_precision='%.3f')

    slpt = (int)(0.9 * original.shape[0])

    training_set = original.iloc[0:slpt,0:5].values.tolist()
    training_target = original.iloc[0:slpt,-1].values.tolist()
    test_set = original.iloc[slpt:original.shape[0],0:5].values.tolist()
    test_target = original.iloc[slpt:original.shape[0], -1].values.tolist()


    #
    # # Specify that all features have real-value data
    feature_columns = [tf.feature_column.numeric_column("x", shape=[5])]
    #
    # # Build 3 layer DNN with 10, 20, 10 units respectively.
    # classifier = tf.estimator.DNNClassifier(feature_columns=feature_columns,
    #                                   hidden_units=[10, 20, 10],
    #                                   n_classes=3,
    #                                   model_dir="/tmp/iris_model")

    regressor = tf.estimator.DNNRegressor(feature_columns=feature_columns,
                                      hidden_units=[10, 20,30,20, 10],
                                      model_dir="model/test1")
    # # Define the training inputs
    train_input_fn = tf.estimator.inputs.numpy_input_fn(
        x={"x": np.array(training_set)},
        y=np.array(training_target),
        num_epochs=None,
        shuffle=True)
    #
    # # Train model.
    regressor.train(input_fn=train_input_fn, steps=6000)
    #
    # # Define the test inputs
    test_input_fn = tf.estimator.inputs.numpy_input_fn(
        x={"x": np.array(test_set)},
        y=np.array(test_target),
        num_epochs=1,
        shuffle=False)
    #
    evl = regressor.evaluate(input_fn=test_input_fn)
    # # Evaluate accuracy.
    # accuracy_score = regressor.evaluate(input_fn=test_input_fn)["accuracy"]
    #
    print('eval:' + str(evl))
    #
    # Classify two new flower samples.


    # new_samples = np.array([[0.393,0.786,0.697,0.805,0.054]], dtype=np.float32) #0.422 is the answer
    # predict_input_fn = tf.estimator.inputs.numpy_input_fn(
    #     x={"x": new_samples},
    #     num_epochs=1,
    #     shuffle=False)
    # predictions = list(regressor.predict(input_fn=predict_input_fn))

    new_samples = np.array(test_set)
    predict_input_fn = tf.estimator.inputs.numpy_input_fn(
        x={"x": new_samples},
        num_epochs=1,
        shuffle=False)
    predictions = list(regressor.predict(input_fn=predict_input_fn))
    print('predictions' + str(predictions))

    val = []
    for i in range(len(predictions)):
        val.append(predictions[i]['predictions'][0])
    # plt.plot(predictions)
    # plt.plot(predictions)

    def kl_divergence(p, q):
        sess = tf.Session()
        return sess.run(tf.reduce_sum(p * tf.log(p / q)))
    # print(tf.distributions.kl_divergence(val, test_target))
    print(kl_divergence(tf.constant(test_target), tf.constant(val)))

    # print('val' + str(val))

    # ----------------------------------------------------------------------------------------------
    # preplt, = plt.bar(val, '-o', label = 'prediction', color = 'red')
    # relplt, = plt.bar(test_target, '-^', label = 'real', color = 'blue')
    #
    # plt.legend(handles=[relplt, preplt])
    # # predicted_classes = [p["classes"] for p in predictions]
    # #
    # # print("New Samples, Class Predictions:    {}\n".format(predicted_classes))
    # plt.show()

    #----------------------------------------------------------------------------------------------
    # ind = np.arange(len(val))
    # preplt, = plt.bar(ind, (np.array(val) - np.array(test_target)).tolist(), label = 'prediction', color = 'red')

    # relplt, = plt.bar(test_target, '-^', label = 'real', color = 'blue')
    preplt, = plt.plot((np.abs(np.array(val) - np.array(test_target))/np.array(test_target)).tolist(), '.', label='prediction', color='red')

    plt.legend(handles=[preplt])
    # predicted_classes = [p["classes"] for p in predictions]
    #
    # print("New Samples, Class Predictions:    {}\n".format(predicted_classes))
    plt.show()

if __name__ == "__main__":
    # def kl_divergence(p, q):
    #     sess = tf.Session()
    #     return sess.run(tf.reduce_sum(p * tf.log(p / q)))
    # print(tf.distributions.kl_divergence(val, test_target))
    # print(kl_divergence(tf.constant([1.0,2,3]), tf.constant([1.0,2,3])))
    main()



