
import tensorflow as tf
import pandas as pd
import matplotlib.pyplot as plt
import gandiscrete_3_clmethods as gan

def sample_gumbel(shape, eps=1e-20):
  """Sample from Gumbel(0, 1)"""
  U = tf.random_uniform(shape,minval=0,maxval=1)
  return -tf.log(-tf.log(U + eps) + eps)

def gumbel_softmax_sample(logits, temperature):
  """ Draw a sample from the Gumbel-Softmax distribution"""
  y = logits + sample_gumbel(tf.shape(logits))
  return tf.nn.softmax( y / temperature)

def gumbel_softmax(logits, temperature, hard=False):
  """Sample from the Gumbel-Softmax distribution and optionally discretize.
  Args:
    logits: [batch_size, n_class] unnormalized log-probs
    temperature: non-negative scalar
    hard: if True, take argmax, but differentiate w.r.t. soft sample y
  Returns:
    [batch_size, n_class] sample from the Gumbel-Softmax distribution.
    If hard=True, then the returned sample will be one-hot, otherwise it will
    be a probabilitiy distribution that sums to 1 across classes
  """
  y = gumbel_softmax_sample(logits, temperature)
  if hard:
    k = tf.shape(logits)[-1]
    #y_hard = tf.cast(tf.one_hot(tf.argmax(y,1),k), y.dtype)
    y_hard = tf.cast(tf.equal(y,tf.reduce_max(y,1,keep_dims=True)),y.dtype)
    y = tf.stop_gradient(y_hard - y) + y
  return y




def simplyplot(filename):
    plt.style.use('ggplot')
    original = pd.read_csv(filename)
    # original = gd.genran2()




    #----------------------------------------------
    scale = 2.5
    fig, axs = plt.subplots(2, 3, figsize=(9*scale, 3*scale), sharey=True)
    # original.plot.bar(stacked=True)
    # original.plot.hist(stacked=True)
    # ser = pd.Series(original['A'])
    # original['A'].value_counts(sort=False).plot(ax = axs[0,0],kind ='bar')
    # original['B'].value_counts(sort=False).plot(ax = axs[0,1],kind ='bar')
    # original['C'].value_counts(sort=False).plot(ax = axs[0,2],kind ='bar')
    # original['D'].value_counts(sort=False).plot(ax = axs[1,0],kind ='bar')
    # original['E'].value_counts(sort=False).plot(ax = axs[1,1],kind ='bar')
    # original['F'].value_counts(sort=False).plot(ax = axs[1,2],kind ='bar')


    #----------------------------------------------

    original['A'].plot(ax = axs[0,0],kind ='hist')
    original['B'].plot(ax = axs[0,1],kind ='hist')
    original['C'].plot(ax = axs[0,2],kind ='hist')
    original['D'].plot(ax = axs[1,0],kind ='hist')
    original['E'].plot(ax = axs[1,1],kind ='hist')
    original['F'].plot(ax = axs[1,2],kind ='hist')

    fig.suptitle(filename)

    plt.show()
    #----------------------------------------------


    # original.plot(kind = 'density')
    #
    #
    # plt.show()

def main():
    print('here')
    # original = pd.read_csv('data/test2.csv', float_precision='%.3f')

    headers = ['age', 'hworkclass', 'fnlwgt', 'education',
             'education-num', 'marital-status', 'occupation',
             'relationship', 'race', 'sex', 'capital-gain',
             'capital-loss', 'hours-per-week', 'native-country', 'class']

    # Read in the CSV file and convert "?" to NaN

    df = pd.read_csv('data/adult.data',header=None, names=headers, na_values="?")
    df = df.select_dtypes(include=['object'])

    print(df.head())


    # df = df.apply(lambda x: x.astype('category'))

    df_onehot = pd.get_dummies(df)
    # print(df_onehot)
    #
    #
    res = gumbel_softmax(df_onehot.values, 0.2, hard=False)
    sess = tf.Session()
    res = sess.run(res)
    print(res)
    res = pd.DataFrame(res)
    gan.gan_org(res, splitpoint=0.9)


    # for i in range(10):
    #     print(sum(res[i]))



    # print('original')
  # print(df.values)
  # print('gumbel')
  #
  # # gumbel_softmax(original, 0.2, hard=True)
  # # res = gumbel_softmax(original.iloc[:,0:1].values, 0.2, hard=False)
  # res = gumbel_softmax(df.values, 0.2, hard=False)
  # sess = tf.Session()
  # res = sess.run(res)
  # print(res)

if  __name__ == '__main__':
  main()