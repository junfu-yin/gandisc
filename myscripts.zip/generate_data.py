import pandas as pd
import numpy as np

import matplotlib.pyplot as plt



def genran1():
    df = pd.DataFrame(np.random.randint(0,100,size=(100, 4)), columns=list('ABCD'))
    # df1['randNumCol'] = np.random.randint(1, 6, df1.shape[0])
    df['A'] = np.random.randint(1, 8, size =(100,1))
    df['B'] = np.random.randint(1, 3, size =(100,1))
    df['C'] = np.random.randint(1, 31, size =(100,1))
    df['D'] = np.random.randint(1, 11, size =(100,1))
    df['E'] = np.random.randint(1, 11, size =(100,1))
    df['F'] = np.random.randint(1, 50, size =(100,1))



    df.to_csv('test1.csv', header=True, index_label=False, index=False)

    with open('test1.csv') as f:
        st = f.read()

def genran2():
    df = pd.DataFrame(np.random.randint(0,100,size=(100, 4)), columns=list('ABCD'))
    # df1['randNumCol'] = np.random.randint(1, 6, df1.shape[0])
    df['A'] = np.random.randint(1, 8, size =(100,1))
    df['B'] = np.random.randint(1, 3, size =(100,1))
    df['C'] = np.random.randint(1, 31, size =(100,1))


    df['D'] = np.random.logistic(30, 2, size=(100, 1)).astype(int)
    df['E'] = np.random.poisson(2, size=(100, 1))
    df['F'] = np.random.normal(10, 1.5, size =(100,1)).astype(int)



    df.to_csv('test1.csv', header=True, index_label=False, index=False)

    with open('test1.csv') as f:
        st = f.read()
    return df


def genran3(size = 100):
    pd.options.display.float_format = '${:,.2f}'.format
    df = pd.DataFrame(np.random.randint(0,size,size=(size, 4)), columns=list('ABCD'))
    # df1['randNumCol'] = np.random.randint(1, 6, df1.shape[0])
    df['A'] = np.random.rand(size,1)
    df['B'] = np.random.rand(size,1)
    df['C'] = np.random.rand(size,1)


    df['D'] = np.random.logistic(0.8, 0.02, size=(size, 1)).astype(float)

    df['E'] = np.random.normal(0.2, 0.3, size=(size, 1)).astype(float)
    df['F'] = np.random.normal(0.5, 0.1, size =(size,1)).astype(float)


    pd.options.display.float_format = '${:,.2f}'.format

    df.to_csv('test2.csv', header=True, index_label=False, index=False, float_format='%.3f')

    with open('test2.csv') as f:
        st = f.read()
    return df



def main():
    original = genran3(size = 10000)
    scale = 2.5
    fig, axs = plt.subplots(2, 3, figsize=(9*scale, 3*scale), sharey=True)
    # original.plot.bar(stacked=True)
    # original.plot.hist(stacked=True)
    # ser = pd.Series(original['A'])
    # original['A'].value_counts(sort=False).plot(ax = axs[0,0],kind ='bar')
    # original['B'].value_counts(sort=False).plot(ax = axs[0,1],kind ='bar')
    # original['C'].value_counts(sort=False).plot(ax = axs[0,2],kind ='bar')
    # original['D'].value_counts(sort=False).plot(ax = axs[1,0],kind ='bar')
    # original['E'].value_counts(sort=False).plot(ax = axs[1,1],kind ='bar')
    # original['F'].value_counts(sort=False).plot(ax = axs[1,2],kind ='bar')


    #----------------------------------------------

    original['A'].plot(ax = axs[0,0],kind ='hist')
    original['B'].plot(ax = axs[0,1],kind ='hist')
    original['C'].plot(ax = axs[0,2],kind ='hist')
    original['D'].plot(ax = axs[1,0],kind ='hist')
    original['E'].plot(ax = axs[1,1],kind ='hist')
    original['F'].plot(ax = axs[1,2],kind ='hist')


    plt.show()

if __name__ == '__main__':
    main()



